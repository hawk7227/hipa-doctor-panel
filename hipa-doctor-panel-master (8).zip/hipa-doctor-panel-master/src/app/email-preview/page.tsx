import EmailPreview from '@/components/EmailPreview'

export default function EmailPreviewPage() {
  return <EmailPreview />
}

